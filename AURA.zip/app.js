const btn = document.querySelector(".talk");
const content = document.querySelector(".content");

function speak(text) {
  const text_speak = new SpeechSynthesisUtterance(text);

  text_speak.rate = 1;
  text_speak.volume = 1;
  text_speak.pitch = 1;

  window.speechSynthesis.speak(text_speak);
}

window.addEventListener("load", () => {
  speak("Initializing Project AURA..");
});

const SpeechRecognition =
  window.SpeechRecognition || window.webkitSpeechRecognition;

const recognition = new SpeechRecognition();

recognition.onresult = (event) => {
  const currentIndex = event.resultIndex;
  const transcript = event.results[currentIndex][0].transcript;
  content.textContent = transcript;
  takeCommand(transcript.toLowerCase());
};

btn.addEventListener("click", () => {
  content.textContent = "Listening....";
  recognition.start();
});

function takeCommand(message) {
  if (message.includes("hey") || message.includes("hello")) {
    speak("Hello SIR.  I am PROJECT AURA.  What can I do for you?");
  } else if (message.includes("open google")) {
    window.open("https://google.com", "_blank");
    speak(" sure sir , Opening Google... anything else sir?");
  } else if (message.includes("play music")) {
    window.open(
      "https://open.spotify.com/track/38h4tmH1AWBVuemWAy4R4y?si=fe4687cdf55a472d",
      "_blank"
    );
    speak(" sure sir , playing music... anything else sir?");
  } else if (message.includes("open youtube")) {
    window.open("https://youtube.com", "_blank");
    speak(" sure sir , Opening Youtube... anything else sir?");
  } else if (message.includes("open facebook")) {
    window.open("https://facebook.com", "_blank");
    speak("sure sir , Opening Facebook...");
  }  else if (message.includes("open instagram")) {
    window.open("https://instagram.com", "_blank");
    speak("sure sir , Opening instagram... anything else sir?");
  } else if (message.includes("open youtube")) {
    window.open("https://youtube.com", "_blank");
    speak("sure sir , Opening youtube... anything else sir?");
  } else if (message.includes("open gmail")) {
    window.open("https://mail.google.com", "_blank");
    speak("sure sir , Opening gmail... anything else sir?");
  } else if (message.includes("tell me something about yourself")) {
    speak(
      "sure sir , I am PROJECT AURA, Developed by Mister shree . I am a virtual assistant to help you.  "
    );
  } else if (
    message.includes("what is") ||
    message.includes("who is") ||
    message.includes("what are")
  ) {
    window.open(
      `https://www.google.com/search?q=${message.replace(" ", "+")}`,
      "_blank"
    );
    const finalText = " sure sir , This is what i found regarding " + message;
    speak(finalText);
  } else if (message.includes("wikipedia")) {
    window.open(
      `https://en.wikipedia.org/wiki/${message.replace("wikipedia", "")}`,
      "_blank"
    );
    const finalText = "sure sir , This is what i found regarding " + message;
    speak(finalText);
  } else if (message.includes("time")) {
    const time = new Date().toLocaleString(undefined, {
      hour: "numeric",
      minute: "numeric",
    });
    const finalText = time;
    speak(finalText);
  } else if (message.includes("date")) {
    const date = new Date().toLocaleString(undefined, {
      month: "short",
      day: "numeric",
    });
    const finalText = date;
    speak(finalText);
  } else if (message.includes("calculator")) {
    window.open("Calculator:///");
    const finalText = " sure sir , Opening Calculator";
    speak(finalText);
  } else {
    window.open(
      `https://www.google.com/search?q=${message.replace(" ", "+")}`,
      "_blank"
    );
    const finalText =
      "sure sir , I found some information for " + message + " on google";
    speak(finalText);
  }
}
